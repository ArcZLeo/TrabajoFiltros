package com.example.alumnos.model;

import javax.persistence.*;
import java.sql.Date;


@Entity
@Table(name = "alumno")
public class Alumno {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column(nullable = false, length = 100)
    private String nombre;

    @Column(nullable = false, length = 100)
    private String apellidoM;

    @Column(nullable = false, length = 100)
    private String apellidoP;


    @Column(nullable = false, length = 100)
    private String dni;

    @Column(nullable = true,columnDefinition = "Boolean default false")
    private Boolean estado;

    @Column(nullable = false)
    private Date fecha_maciento;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidoM() {
        return apellidoM;
    }

    public void setApellidoM(String apellidoM) {
        this.apellidoM = apellidoM;
    }

    public String getApellidoP() {
        return apellidoP;
    }

    public void setApellidoP(String apellidoP) {
        this.apellidoP = apellidoP;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public Boolean getEstado() {
        return estado;
    }

    public void setEstado(Boolean estado) {
        this.estado = estado;
    }

    public Date getFecha_maciento() {
        return fecha_maciento;
    }

    public void setFecha_maciento(Date fecha_maciento) {
        this.fecha_maciento = fecha_maciento;
    }
}
