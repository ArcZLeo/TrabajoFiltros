package com.example.alumnos.repository;

import com.example.alumnos.model.Alumno;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface AlumnoInterface extends JpaRepository<Alumno,Long> {
    //List<Alumno> findAllTrue();
}
