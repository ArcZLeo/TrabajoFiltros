package com.example.alumnos.repository;

import com.example.alumnos.model.AlumnoDetalle;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AlumnoDetalleInterface extends JpaRepository<AlumnoDetalle,Long> {
}
