package com.example.alumnos.model;


public class Creador {
	public Alumno alumno;
    public AlumnoDetalle detalle;

}
