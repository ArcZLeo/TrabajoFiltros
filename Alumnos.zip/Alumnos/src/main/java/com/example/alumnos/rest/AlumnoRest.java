package com.example.alumnos.rest;

import com.example.alumnos.model.Alumno;
import com.example.alumnos.model.AlumnoDetalle;
import com.example.alumnos.model.Creador;
import com.example.alumnos.service.AlumnoDetalleService;
import com.example.alumnos.service.AlumnoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.sql.Array;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

@RestController
@RequestMapping("/alumno/")
public class AlumnoRest {
    @Autowired
    private AlumnoService alumnoService;
    private AlumnoDetalleService alumnoDetalleService;

    @GetMapping ("update/{id}")
    private ResponseEntity<String> estadoAlumno(@PathVariable("id") Long id){
        try {
            alumnoService.updateEstado(id);
            return ResponseEntity.created(new URI("/alumno/")).body("Matricula Creada");
        }catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }
    }

    @GetMapping
    private ResponseEntity<List<Alumno>> AlumnosTrue(){
        return ResponseEntity.ok(alumnoService.findAll());
    }

    @PostMapping
    private ResponseEntity<Alumno> saveAlumno (@RequestBody Creador creador){
        try {
            Alumno alumnoGuardado = alumnoService.save(creador.alumno);
            alumnoDetalleService.save(creador.detalle);
            return ResponseEntity.created(new URI("/alumno/"+alumnoGuardado.getId())).body(alumnoGuardado);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }
    }

    @PostMapping("all/")
    private void /*ResponseEntity<Alumno>*/ saveAlumnos (@RequestBody List<Creador> creador){
        for (int i=0; i<creador.size(); i++) {
            alumnoService.save(creador.get(i).alumno);
            //alumnoDetalleService.save(creador.get(i).detalle);
        }

    }


    @GetMapping("/{nombre}/{apellidoP}/{apellidoM}")
    private ResponseEntity<List<Alumno>> AlumnoFiltro(@PathVariable("nombre") String nombre,@PathVariable("apellidoP") String apellidoP,@PathVariable("apellidoM") String apellidoM){
    	long startTime = System.currentTimeMillis();
    	List<Alumno> alumnoGuardado = alumnoService.FiltrosA(nombre, apellidoP, apellidoM);
    	long endTime = System.currentTimeMillis() - startTime;
    	System.out.println(endTime);
    	return ResponseEntity.ok(alumnoGuardado);
    }

    @GetMapping("/{dni}")
    private ResponseEntity<List<Alumno>> AlumnoFiltroD(@PathVariable("dni") String dni){
    	long startTime = System.currentTimeMillis();
    	List<Alumno> alumnoGuardado = alumnoService.FiltrosAD(dni);
    	long endTime = System.currentTimeMillis() - startTime;
    	System.out.println(endTime);
    	return ResponseEntity.ok(alumnoService.FiltrosAD(dni));
    }
    
}

