package com.example.alumnos.rest;

import com.example.alumnos.model.Alumno;
import com.example.alumnos.service.AlumnoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/alumno/")
public class AlumnoRest {
    @Autowired
    private AlumnoService alumnoService;

    @GetMapping ("update/{id}")
    private ResponseEntity<String> estadoAlumno(@PathVariable("id") Long id){
        try {
            alumnoService.updateEstado(id);
            return ResponseEntity.created(new URI("/alumno/")).body("Matricula Creada");
        }catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }
    }

    @GetMapping
    private ResponseEntity<List<Alumno>> AlumnosTrue(){
        return ResponseEntity.ok(alumnoService.findAll());
    }

    @GetMapping
    private ResponseEntity<List<Alumno>> AlumnosFiltros(){
        return ResponseEntity.ok(alumnoService.findAll());
    }

}
