package com.example.alumnos.service;

import com.example.alumnos.model.Alumno;
import com.example.alumnos.model.AlumnoDetalle;
import com.example.alumnos.repository.AlumnoDetalleInterface;
import com.example.alumnos.repository.AlumnoInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.repository.query.FluentQuery;

import java.util.List;
import java.util.Optional;
import java.util.function.Function;

public class AlumnoDetalleService implements AlumnoDetalleInterface {
    @Autowired
    private AlumnoDetalleInterface alumnoDetalleInterface;

    @Override
    public List<AlumnoDetalle> findAll() {
        return alumnoDetalleInterface.findAll();
    }

    @Override
    public Optional<AlumnoDetalle> findById(Long aLong) {
        return alumnoDetalleInterface.findById(aLong);
    }



    @Override
    public List<AlumnoDetalle> findAll(Sort sort) {
        return null;
    }

    @Override
    public Page<AlumnoDetalle> findAll(Pageable pageable) {
        return null;
    }

    @Override
    public List<AlumnoDetalle> findAllById(Iterable<Long> longs) {
        return null;
    }

    @Override
    public long count() {
        return 0;
    }

    @Override
    public void deleteById(Long aLong) {

    }

    @Override
    public void delete(AlumnoDetalle entity) {

    }

    @Override
    public void deleteAllById(Iterable<? extends Long> longs) {

    }

    @Override
    public void deleteAll(Iterable<? extends AlumnoDetalle> entities) {

    }

    @Override
    public void deleteAll() {

    }

    @Override
    public <S extends AlumnoDetalle> S save(S entity) {
        return null;
    }

    @Override
    public <S extends AlumnoDetalle> List<S> saveAll(Iterable<S> entities) {
        return null;
    }


    @Override
    public boolean existsById(Long aLong) {
        return false;
    }

    @Override
    public void flush() {

    }

    @Override
    public <S extends AlumnoDetalle> S saveAndFlush(S entity) {
        return null;
    }

    @Override
    public <S extends AlumnoDetalle> List<S> saveAllAndFlush(Iterable<S> entities) {
        return null;
    }

    @Override
    public void deleteAllInBatch(Iterable<AlumnoDetalle> entities) {

    }

    @Override
    public void deleteAllByIdInBatch(Iterable<Long> longs) {

    }

    @Override
    public void deleteAllInBatch() {

    }

    @Override
    public AlumnoDetalle getOne(Long aLong) {
        return null;
    }

    @Override
    public AlumnoDetalle getById(Long aLong) {
        return null;
    }

    @Override
    public AlumnoDetalle getReferenceById(Long aLong) {
        return null;
    }

    @Override
    public <S extends AlumnoDetalle> Optional<S> findOne(Example<S> example) {
        return Optional.empty();
    }

    @Override
    public <S extends AlumnoDetalle> List<S> findAll(Example<S> example) {
        return null;
    }

    @Override
    public <S extends AlumnoDetalle> List<S> findAll(Example<S> example, Sort sort) {
        return null;
    }

    @Override
    public <S extends AlumnoDetalle> Page<S> findAll(Example<S> example, Pageable pageable) {
        return null;
    }

    @Override
    public <S extends AlumnoDetalle> long count(Example<S> example) {
        return 0;
    }

    @Override
    public <S extends AlumnoDetalle> boolean exists(Example<S> example) {
        return false;
    }

    @Override
    public <S extends AlumnoDetalle, R> R findBy(Example<S> example, Function<FluentQuery.FetchableFluentQuery<S>, R> queryFunction) {
        return null;
    }
}
